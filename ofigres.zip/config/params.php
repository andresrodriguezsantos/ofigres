<?php

return [
    'adminEmail' => 'greensoftw@hotmail.com',
];
